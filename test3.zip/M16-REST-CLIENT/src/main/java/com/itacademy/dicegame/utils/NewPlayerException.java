package com.itacademy.dicegame.utils;

public class NewPlayerException extends RuntimeException{
	/*
	 * Class used by AuthenticatorDiceGame.class 
	 */
}
