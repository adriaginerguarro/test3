package com.itacademy.dicegame.domain.diceGame;

public class GameType
{
    public static final String OneDiceGame = "OneDiceGame"; 
    public static final  String TwoDiceGame = "TwoDiceGame"; 
    public static final String ThreeDiceGame = "ThreeDiceGame";

}
